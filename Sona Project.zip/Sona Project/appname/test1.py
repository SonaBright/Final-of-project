from flask import Flask, request, flash, url_for, redirect, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'postgresql://postgres:root@localhost/smart_village_monitoring'
app.config['SECRET_KEY'] = "random string"
db = SQLAlchemy(app)

@app.route('/hom1')
def hom1():
   return render_template("hom1.html")   
@app.route('/logi1')
def logi1():
   return render_template("logi1.html") 
@app.route('/userdetails/<name>')
def userdetails(name):
	return render_template("userdetails.html",sign1=sign1.query.filter_by(Username='%s'%name))    
@app.route('/contact1')
def contact1():
   return render_template("contact1.html")   
@app.route('/about')
def about():
   return render_template("about.html")   
@app.route('/sign1')
def sign1():
   return render_template("sign1.html")  
@app.route('/admin1')
def admin1():
   return render_template("admin1.html")   
@app.route('/user1')
def user1():
   return render_template("user1.html")           
@app.route('/hc1')
def hc1():
   return render_template("hc1.html")   
@app.route('/roads1')
def roads1():
   return render_template("roads1.html")   
@app.route('/tp1')
def tp1():
   return render_template("tp1.html")   
@app.route('/edu1')
def edu1():
   return render_template("edu1.html")
@app.route('/viewsearch1/<name>')
def viewsearch1(name):
	return render_template("viewsearch1.html",sign1=sign1.query.filter_by(Username='%s'%name))	   
@app.route('/viewhc1')
def viewhc1():
   return render_template("viewhc1.html",health1=health1.query.all())
@app.route('/viewroads1')
def viewroads1():
   return render_template("viewroads1.html",road1=road1.query.all())
@app.route('/viewtp1')
def viewtp1():
   return render_template("viewtp1.html",transportation1=transportation1.query.all())
@app.route('/viewedu1')
def viewedu1():
   return render_template("viewedu1.html",educationn1=educationn1.query.all())
@app.route('/search1')
def search1():
	return render_template("search1.html")   
@app.route('/view1')
def view1():
	return render_template("view1.html",sign1=sign1.query.all()) 	  
   
class sign1(db.Model):
	id = db.Column('su1_id', db.Integer, primary_key = True)
	Username = db.Column(db.String(100))
	Password = db.Column(db.String(200)) 
	Gender = db.Column(db.String(100))
	Email = db.Column(db.String(200))
	District = db.Column(db.String(200))
	Village = db.Column(db.String(200))
	Phone_Number = db.Column(db.String(200))
	def __init__(self, Username, Password, Gender, Email, District, Village, Phone_Number):
		self.Username = Username 
		self.Password = Password
		self.Gender = Gender
		self.Email = Email
		self.District = District
		self.Village = Village
		self.Phone_Number = Phone_Number
	@app.route('/sign1', methods = ['GET', 'POST'])
	def new():
		if request.method == 'POST':
			if not request.form['Username'] or not request.form['Password'] or not request.form['Gender'] or not request.form['Email'] or not request.form['District'] or not request.form['Village'] or not request.form['Phone_Number']:
				flash('Please enter all the fields', 'error')
			else:
				su1 = sign1(request.form['Username'], request.form['Password'], request.form['Gender'], request.form['Email'], request.form['District'], request.form['Village'], request.form['Phone_Number'])
				db.session.add(su1)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('logi1'))
		return render_template('sign1.html')
		
@app.route('/logi1', methods=['POST','GET'])
def loginn1():
	if request.method=='GET':
		return render_template('logi1.html')
	Username = request.form['Username']
	Password = request.form['Password']
	su1=sign1.query.filter_by(Username=Username,Password=Password).first()
	if request.form['Password'] == 'admin' and request.form['Username'] == 'admin':
		return render_template("admin1.html")
	if su1 is None:
		return render_template("logi1.html")
	else:
		return redirect(url_for("userdetails",name=Username))
		
class health1(db.Model):
	id = db.Column('hc1_id', db.Integer, primary_key = True)
	Total_count_of_people = db.Column(db.Integer())
	Frequent_disorders = db.Column(db.String(100))
	Nearby_hospital_distance = db.Column(db.Integer())
	def __init__(self, Total_count_of_people, Frequent_disorders,Nearby_hospital_distance):
		self.Total_count_of_people = Total_count_of_people 
		self.Frequent_disorders = Frequent_disorders
		self.Nearby_hospital_distance = Nearby_hospital_distance
	@app.route('/hc1', methods = ['GET', 'POST'])
	def new3():
		if request.method == 'POST':
			if not request.form['Total_count_of_people'] or not request.form['Frequent_disorders'] or not request.form['Nearby_hospital_distance']:
				flash('Please enter all the fields', 'error')
			else:
				hc1 = health1(request.form['Total_count_of_people'], request.form['Frequent_disorders'], request.form['Nearby_hospital_distance'])
				db.session.add(hc1)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('user1'))
		return render_template('hc1.html')

class road1(db.Model):
	id = db.Column('roads1_id', db.Integer, primary_key = True)
	Name_of_the_areas = db.Column(db.String(100))
	Number_of_buildings_on_the_road = db.Column(db.Integer())
	Number_of_trees_on_the_road = db.Column(db.Integer())
	Length_of_the_road = db.Column(db.Integer())
	Breadth_of_the_road = db.Column(db.Integer())
	Areas_to_be_re_constructed = db.Column(db.String(100))
	def __init__(self, Name_of_the_areas, Number_of_buildings_on_the_road, Number_of_trees_on_the_road, Length_of_the_road, Breadth_of_the_road,Areas_to_be_re_constructed): 
		self.Name_of_the_areas = Name_of_the_areas
		self.Number_of_buildings_on_the_road = Number_of_buildings_on_the_road
		self.Number_of_trees_on_the_road = Number_of_trees_on_the_road
		self.Length_of_the_road = Length_of_the_road
		self.Breadth_of_the_road = Breadth_of_the_road
		self.Areas_to_be_re_constructed = Areas_to_be_re_constructed
	@app.route('/roads1', methods = ['GET', 'POST'])
	def new4():
		if request.method == 'POST':
			if not request.form['Name_of_the_areas'] or not request.form['Number_of_buildings_on_the_road'] or not request.form['Number_of_trees_on_the_road'] or not request.form['Length_of_the_road'] or not request.form['Breadth_of_the_road'] or not request.form['Areas_to_be_re_constructed']:
				flash('Please enter all the fields', 'error')
			else:
				roads1 = road1(request.form['Name_of_the_areas'], request.form['Number_of_buildings_on_the_road'], request.form['Number_of_trees_on_the_road'], request.form['Length_of_the_road'], request.form['Breadth_of_the_road'], request.form['Areas_to_be_re_constructed'])
				db.session.add(roads1)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('user1'))
		return render_template('roads1.html')

class transportation1(db.Model):
	id = db.Column('transport1_id', db.Integer, primary_key = True)
	Total_count_of_people = db.Column(db.Integer())
	Name_of_the_areas = db.Column(db.String(200))
	Length_of_the_road = db.Column(db.Integer())
	Breadth_of_the_road = db.Column(db.Integer())
	Areas_of_frequent_accidents = db.Column(db.String(200))
	def __init__(self, Total_count_of_people, Name_of_the_areas, Length_of_the_road, Breadth_of_the_road, Areas_of_frequent_accidents): 
		self.Total_count_of_people = Total_count_of_people 
		self.Name_of_the_areas = Name_of_the_areas
		self.Length_of_the_road = Length_of_the_road
		self.Breadth_of_the_road = Breadth_of_the_road
		self.Areas_of_frequent_accidents = Areas_of_frequent_accidents
	@app.route('/tp1', methods = ['GET', 'POST'])
	def new5():
		if request.method == 'POST':
			if not request.form['Total_count_of_people'] or not request.form['Name_of_the_areas'] or not request.form['Length_of_the_road'] or not request.form['Breadth_of_the_road'] or not request.form['Areas_of_frequent_accidents']:
				flash('Please enter all the fields', 'error')
			else:
				transport1 = transportation1(request.form['Total_count_of_people'], request.form['Name_of_the_areas'], request.form['Length_of_the_road'], request.form['Breadth_of_the_road'], request.form['Areas_of_frequent_accidents'])
				db.session.add(transport1)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('user1'))
		return render_template('tp1.html')

class educationn1(db.Model):
	id = db.Column('edu1_id', db.Integer, primary_key = True)
	Number_of_children = db.Column(db.Integer())
	Type_of_school_needed = db.Column(db.String(200))
	Nearby_school_distance = db.Column(db.Integer())
	Name_of_the_nearby_school_areas = db.Column(db.String(200))
	def __init__(self, Number_of_children, Type_of_school_needed, Nearby_school_distance, Name_of_the_nearby_school_areas ): 
		self.Number_of_children = Number_of_children
		self.Type_of_school_needed = Type_of_school_needed
		self.Nearby_school_distance = Nearby_school_distance
		self.Name_of_the_nearby_school_areas = Name_of_the_nearby_school_areas
	@app.route('/edu1', methods = ['GET', 'POST'])
	def educate1():
		if request.method == 'POST':
			if not request.form['Number_of_children'] or not request.form['Type_of_school_needed'] or not request.form['Nearby_school_distance'] or not request.form['Name_of_the_nearby_school_areas']:
				flash('Please enter all the fields', 'error')
			else:
				edu1 = educationn1(request.form['Number_of_children'], request.form['Type_of_school_needed'], request.form['Nearby_school_distance'], request.form['Name_of_the_nearby_school_areas'])
				db.session.add(edu1)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('user1'))
		return render_template('edu1.html')				

class contact1(db.Model):
	id = db.Column('contacts_id', db.Integer, primary_key = True)
	Username = db.Column(db.String(100))
	Email = db.Column(db.String(200))
	Village = db.Column(db.String(200))
	Feedback = db.Column(db.String(200))
	def __init__(self, Username, Email, Village, Feedback): 
		self.Username = Username 
		self.Email = Email
		self.Village = Village
		self.Feedback = Feedback
	@app.route('/contact1', methods = ['GET', 'POST'])
	def con1():
		if request.method == 'POST':
			if not request.form['Username'] or not request.form['Email'] or not request.form['Village'] or not request.form['Feedback']:
				flash('Please enter all the fields', 'error')
			else:
				contacts1 = contact1(request.form['Username'], request.form['Email'], request.form['Village'], request.form['Feedback'])
				db.session.add(contacts1)
				db.session.commit()
				flash('Record was successfully added')
				return redirect(url_for('hom1'))
		return render_template('contact1.html')
		
@app.route('/search1', methods=['POST','GET'])
def searchh1():
	if request.method=='POST':
		Username = request.form['Username']
		return redirect(url_for("viewsearch1",name=Username))				
		
if __name__ == '__main__':
	db.create_all()
	app.run(debug = True)
